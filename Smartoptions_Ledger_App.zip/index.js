import React from 'react';
import ReactDOM from 'react-dom/client';
import SmartOptionsApp from './SmartOptionsApp';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<SmartOptionsApp />);
